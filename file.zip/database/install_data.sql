--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `created_at`) VALUES
(1, 'michael sanchez', 'admin@example.com', '$2y$10$8qDFHCQZXm6hi3ChuiN0ruZDETONlSOBfOFoRaw/ApwSuMnDXVDV6', '2025-06-11 08:29:07');

--
-- Indexes for dumped tables
--