    </main>
    <footer>
        <p style="text-align: center; margin-top: 40px; color: #999;">&copy; <?= date('Y'); ?> Ecosys Training Center. All rights reserved.</p>
    </footer>
</body>
</html>
