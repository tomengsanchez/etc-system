<div class="p-5 mb-4 bg-light rounded-3">
    <div class="container-fluid py-5">
        <h1 class="display-5 fw-bold"><?= $data['title']; ?></h1>
        <p class="col-md-8 fs-4"><?= $data['description']; ?></p>
        <p>This demonstrates a simple homepage in the custom PHP MVC framework, now styled with Bootstrap 5.</p>
    </div>
</div>
